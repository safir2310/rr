'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Mail, Phone, MapPin, ShoppingBag, Star, LogOut, Edit, Camera, ShoppingCart, Download } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import ProductCard from './ProductCard';
import CartModal from './CartModal';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  isPromotion: boolean;
  isNew: boolean;
}

interface Order {
  id: string;
  orderNumber: string;
  status: string;
  totalAmount: number;
  pointsEarned: number;
  createdAt: string;
  orderItems: {
    product: {
      name: string;
      price: number;
    };
    quantity: number;
  }[];
}

interface UserDashboardProps {
  onClose: () => void;
}

export default function UserDashboard({ onClose }: UserDashboardProps) {
  const { user, setUser, logout } = useAuthStore();
  const { items, toggleCart, isOpen: isCartOpen } = useCartStore();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'menu' | 'favorites'>('profile');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [editingProfile, setEditingProfile] = useState(false);
  const [loading, setLoading] = useState(false);

  const [profileData, setProfileData] = useState({
    username: user?.username || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
    newPassword: ''
  });

  useEffect(() => {
    if (user) {
      setProfileData({
        username: user.username,
        email: user.email,
        phone: user.phone || '',
        address: user.address || '',
        newPassword: ''
      });
      fetchOrders();
      fetchProducts();
      loadFavorites();
    }
  }, [user]);

  const fetchOrders = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/orders?userId=${user.id}`);
      const data = await res.json();
      setOrders(data.orders || []);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      setProducts(data.products || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const loadFavorites = () => {
    const saved = localStorage.getItem('favorites');
    if (saved) {
      setFavorites(JSON.parse(saved));
    }
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    setLoading(true);

    try {
      const res = await fetch(`/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileData)
      });

      const data = await res.json();

      if (res.ok) {
        setUser(data.user);
        localStorage.setItem('user', JSON.stringify(data.user));
        setEditingProfile(false);
        alert('Profil berhasil diupdate!');
      } else {
        alert(data.error || 'Gagal mengupdate profil');
      }
    } catch (error) {
      alert('Terjadi kesalahan. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    localStorage.removeItem('user');
    localStorage.removeItem('cart');
    onClose();
  };

  const handleCheckout = async (cartItems: any[]) => {
    // Refresh orders after checkout
    await fetchOrders();
  };

  const toggleFavorite = (productId: string) => {
    const newFavorites = favorites.includes(productId)
      ? favorites.filter(id => id !== productId)
      : [...favorites, productId];

    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Menunggu Persetujuan';
      case 'processing':
        return 'Diproses';
      case 'completed':
        return 'Selesai';
      default:
        return status;
    }
  };

  const handleViewReceipt = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/receipt`);
      const data = await res.json();

      if (res.ok && data.receipt) {
        // Create a new window with the receipt
        const receiptWindow = window.open('', '_blank');
        if (receiptWindow) {
          receiptWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
              <title>Struk Pesanan</title>
              <style>
                body {
                  font-family: 'Courier New', monospace;
                  padding: 20px;
                  background: #f5f5f5;
                  display: flex;
                  justify-content: center;
                }
                .receipt {
                  background: white;
                  padding: 30px;
                  max-width: 400px;
                  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .receipt h2 {
                  text-align: center;
                  margin-bottom: 20px;
                  color: #f97316;
                }
                .receipt pre {
                  white-space: pre-wrap;
                  line-height: 1.6;
                }
                @media print {
                  body { background: white; }
                  .receipt { box-shadow: none; }
                }
              </style>
            </head>
            <body>
              <div class="receipt">
                <h2>AYAM GEPREK SAMBAL IJO</h2>
                <pre>${data.receipt.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
                <button onclick="window.print()" style="margin-top: 20px; padding: 10px 20px; background: #f97316; color: white; border: none; border-radius: 5px; cursor: pointer; width: 100%;">
                  Cetak Struk
                </button>
              </div>
            </body>
            </html>
          `);
          receiptWindow.document.close();
        }
      } else {
        alert('Struk tidak ditemukan');
      }
    } catch (error) {
      console.error('Error viewing receipt:', error);
      alert('Gagal memuat struk');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-orange-400 flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-orange-400">
      {/* Header */}
      <header className="bg-orange-500 sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={onClose}
              className="flex items-center gap-2 text-white hover:text-white/80 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-semibold">Kembali</span>
            </button>
            <h1 className="text-white font-bold text-lg">Dashboard User</h1>
            <div className="flex items-center gap-2">
              {/* Cart Button */}
              <button
                onClick={toggleCart}
                className="relative p-2 text-white hover:bg-white/10 rounded-full transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                {items.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                    {items.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-full text-white hover:bg-white/20 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline font-semibold text-sm">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white shadow-md sticky top-16 z-40">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto gap-1 py-2">
            {[
              { id: 'profile' as const, label: 'Profil', icon: User },
              { id: 'orders' as const, label: 'Pesanan', icon: ShoppingBag },
              { id: 'menu' as const, label: 'Menu', icon: ShoppingBag },
              { id: 'favorites' as const, label: 'Favorit', icon: Star }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-orange-500 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        {activeTab === 'profile' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Profile Card */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">Profil Saya</h2>
                <button
                  onClick={() => setEditingProfile(!editingProfile)}
                  className="flex items-center gap-2 text-orange-500 hover:text-orange-600"
                >
                  <Edit className="w-4 h-4" />
                  <span className="font-medium">{editingProfile ? 'Batal' : 'Edit'}</span>
                </button>
              </div>

              {/* Profile Photo */}
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center text-orange-400 text-4xl">
                    {user.photo ? (
                      <img src={user.photo} alt={user.username} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <User className="w-12 h-12" />
                    )}
                  </div>
                  {editingProfile && (
                    <button className="absolute bottom-0 right-0 bg-orange-500 text-white p-2 rounded-full hover:bg-orange-600">
                      <Camera className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Points Display */}
              <div className="bg-gradient-to-br from-orange-500 to-red-500 rounded-xl p-4 mb-6 text-white text-center">
                <p className="text-white/90 mb-1">Total Point</p>
                <p className="text-4xl font-bold">{user.points}</p>
              </div>

              {/* Profile Form */}
              {editingProfile ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                    <input
                      type="text"
                      value={profileData.username}
                      onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">No HP</label>
                    <input
                      type="tel"
                      value={profileData.phone}
                      onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                    <textarea
                      value={profileData.address}
                      onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Password Baru (opsional)</label>
                    <input
                      type="password"
                      value={profileData.newPassword}
                      onChange={(e) => setProfileData({ ...profileData, newPassword: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                      placeholder="Kosongkan jika tidak ingin mengubah"
                    />
                  </div>
                  <button
                    onClick={handleUpdateProfile}
                    disabled={loading}
                    className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Menyimpan...' : 'Simpan Perubahan'}
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <User className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-500">Username</p>
                      <p className="font-semibold text-gray-800">{user.username}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-semibold text-gray-800">{user.email}</p>
                    </div>
                  </div>
                  {user.phone && (
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <Phone className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">No HP</p>
                        <p className="font-semibold text-gray-800">{user.phone}</p>
                      </div>
                    </div>
                  )}
                  {user.address && (
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Alamat</p>
                        <p className="font-semibold text-gray-800">{user.address}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'orders' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {orders.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <ShoppingBag className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">Belum ada pesanan</p>
              </div>
            ) : (
              orders.map((order) => (
                <div key={order.id} className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Order #{order.orderNumber}</p>
                      <p className="font-bold text-gray-800">{formatDate(order.createdAt)}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                      {getStatusText(order.status)}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    {order.orderItems.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-gray-600">{item.quantity}x {item.product.name}</span>
                        <span className="font-semibold">{formatPrice(item.product.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <div>
                      <p className="text-sm text-gray-500">Total</p>
                      <p className="font-bold text-xl text-orange-600">{formatPrice(order.totalAmount)}</p>
                    </div>
                    {order.status === 'completed' && order.pointsEarned > 0 && (
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Point Didapat</p>
                        <p className="font-bold text-green-600">+{order.pointsEarned} poin</p>
                      </div>
                    )}
                  </div>

                  {/* Receipt Button */}
                  <button
                    onClick={() => handleViewReceipt(order.id)}
                    className="w-full mt-4 flex items-center justify-center gap-2 bg-orange-100 text-orange-600 py-2 rounded-lg font-semibold hover:bg-orange-200 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Lihat Struk</span>
                  </button>
                </div>
              ))
            )}
          </motion.div>
        )}

        {activeTab === 'menu' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={(product) => {
                    const cartItem = {
                      id: `${Date.now()}`,
                      productId: product.id,
                      quantity: 1,
                      product
                    };
                    useCartStore.getState().addItem(cartItem);
                    alert(`${product.name} ditambahkan ke keranjang!`);
                  }}
                />
              ))}
            </div>

            {products.length === 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <p className="text-gray-500">Belum ada produk</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'favorites' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products
                .filter((product) => favorites.includes(product.id))
                .map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={(product) => {
                      const cartItem = {
                        id: `${Date.now()}`,
                        productId: product.id,
                        quantity: 1,
                        product
                      };
                      useCartStore.getState().addItem(cartItem);
                      alert(`${product.name} ditambahkan ke keranjang!`);
                    }}
                  />
                ))}
            </div>

            {favorites.length === 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <Star className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">Belum ada produk favorit</p>
              </div>
            )}
          </motion.div>
        )}
      </div>

      {/* Cart Modal */}
      <CartModal
        isOpen={isCartOpen}
        onClose={toggleCart}
        onCheckout={handleCheckout}
      />
    </div>
  );
}
