'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface PromotionPopupProps {
  onClose: () => void;
}

export default function PromotionPopup({ onClose }: PromotionPopupProps) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Check if user has seen the popup
    const hasSeen = localStorage.getItem('promotionPopupSeen');
    if (!hasSeen) {
      setIsOpen(true);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem('promotionPopupSeen', 'true');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/50 z-50"
          />

          {/* Popup */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="bg-white rounded-2xl shadow-2xl max-w-md w-full pointer-events-auto overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-orange-500 to-red-500 p-6 text-white relative">
                <button
                  onClick={handleClose}
                  className="absolute top-4 right-4 p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="text-center">
                  <span className="text-6xl mb-4 block">🔥</span>
                  <h2 className="text-2xl font-bold mb-2">PROMO SPESIAL!</h2>
                  <p className="text-white/90">Dapatkan diskon menarik hari ini</p>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="bg-orange-50 rounded-xl p-4 mb-4">
                  <h3 className="font-bold text-orange-600 text-lg mb-2">Ayam Geprek Paket Hemat</h3>
                  <p className="text-gray-700 mb-2">
                    Nikmati ayam geprek dengan sambal ijo pedas, nasi, dan es teh manis.
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400 line-through">Rp 25.000</span>
                    <span className="text-orange-600 font-bold text-xl">Rp 20.000</span>
                  </div>
                </div>

                <button
                  onClick={handleClose}
                  className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors"
                >
                  Pesan Sekarang
                </button>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
