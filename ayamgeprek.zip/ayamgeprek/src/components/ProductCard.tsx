'use client';

import { motion } from 'framer-motion';
import { ShoppingCart, Plus } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  isPromotion: boolean;
  isNew: boolean;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
    >
      {/* Image */}
      <div className="relative h-48 bg-orange-100 overflow-hidden">
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-orange-300">
            <span className="text-6xl">🍗</span>
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isPromotion && (
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full font-bold">
              PROMO
            </span>
          )}
          {product.isNew && (
            <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full font-bold">
              BARU
            </span>
          )}
        </div>

        {/* Category Badge */}
        <div className="absolute top-2 right-2">
          <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded-full font-medium">
            {product.category === 'food' ? 'Makanan' : 'Minuman'}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-800 mb-2">{product.name}</h3>
        {product.description && (
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>
        )}

        <div className="flex items-center justify-between">
          <p className="text-orange-600 font-bold text-lg">{formatPrice(product.price)}</p>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => onAddToCart(product)}
            className="flex items-center gap-2 bg-orange-500 text-white px-3 py-2 rounded-lg hover:bg-orange-600 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span className="font-semibold text-sm">Tambah</span>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
