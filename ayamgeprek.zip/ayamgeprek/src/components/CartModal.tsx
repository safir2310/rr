'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag, Trash2, Plus, Minus, Loader2 } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';
import { useAuthStore } from '@/store/authStore';

interface CartItem {
  id: string;
  productId: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    price: number;
    image: string | null;
  };
}

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: (cartItems: CartItem[]) => void;
  onShowLogin?: () => void;
}

export default function CartModal({ isOpen, onClose, onCheckout, onShowLogin }: CartModalProps) {
  const { items, removeItem, updateQuantity, clearCart } = useCartStore();
  const { isAuthenticated, user } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [customerNotes, setCustomerNotes] = useState('');

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const totalAmount = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (!isAuthenticated || !user) {
      onShowLogin?.();
      onClose();
      return;
    }

    if (items.length === 0) {
      return;
    }

    setLoading(true);

    try {
      // Create order in database
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          cartItems: items,
          customerNotes
        })
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'Gagal membuat pesanan');
        setLoading(false);
        return;
      }

      const order = data.order;

      // Generate WhatsApp message with order number
      const message = items
        .map(
          (item) =>
            `${item.quantity}x ${item.product.name} - ${formatPrice(item.product.price * item.quantity)}`
        )
        .join('\n');

      const whatsappMessage = encodeURIComponent(
        `Halo, saya ingin memesan:\n\n${message}\n\nTotal: ${formatPrice(totalAmount)}\n\nNomor Order: #${order.orderNumber}\n\nMohon diproses. Terima kasih!`
      );

      const whatsappUrl = `https://wa.me/6285260812758?text=${whatsappMessage}`;

      // Open WhatsApp
      window.open(whatsappUrl, '_blank');

      // Clear cart and notify
      onCheckout(items);
      clearCart();
      onClose();

      // Show success message
      alert(`Pesanan berhasil dibuat!\n\nNomor Order: #${order.orderNumber}\nSilakan tunggu konfirmasi admin.`);
    } catch (error) {
      console.error('Checkout error:', error);
      alert('Terjadi kesalahan. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 z-50"
          />

          {/* Modal */}
          <div className="fixed inset-0 z-50 pointer-events-none">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl pointer-events-auto flex flex-col"
            >
              {/* Header */}
              <div className="bg-orange-500 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5" />
                  <h2 className="font-bold text-lg">Keranjang</h2>
                </div>
                <button
                  onClick={onClose}
                  className="p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto p-4">
                {items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-400">
                    <ShoppingBag className="w-16 h-16 mb-4" />
                    <p>Keranjang kosong</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div
                        key={item.id}
                        className="flex gap-4 bg-gray-50 rounded-lg p-3"
                      >
                        {/* Product Image */}
                        <div className="w-20 h-20 bg-orange-100 rounded-lg overflow-hidden flex-shrink-0">
                          {item.product.image ? (
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-orange-300">
                              🍗
                            </div>
                          )}
                        </div>

                        {/* Product Info */}
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-800 mb-1">{item.product.name}</h3>
                          <p className="text-orange-600 font-bold">{formatPrice(item.product.price)}</p>

                          {/* Quantity Controls */}
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              onClick={() =>
                                updateQuantity(item.id, Math.max(1, item.quantity - 1))
                              }
                              className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="font-semibold w-8 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="ml-auto p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              {items.length > 0 && (
                <div className="border-t border-gray-200 p-4 bg-gray-50">
                  {/* Customer Notes */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Catatan (opsional)
                    </label>
                    <textarea
                      value={customerNotes}
                      onChange={(e) => setCustomerNotes(e.target.value)}
                      placeholder="Catatan untuk pesanan Anda..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none resize-none"
                      rows={2}
                    />
                  </div>

                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-600 font-semibold">Total:</span>
                    <span className="text-orange-600 font-bold text-2xl">{formatPrice(totalAmount)}</span>
                  </div>
                  <button
                    onClick={handleCheckout}
                    disabled={loading}
                    className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Memproses...</span>
                      </>
                    ) : (
                      <span>Checkout WhatsApp</span>
                    )}
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
