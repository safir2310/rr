'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ChefHat, ShoppingCart, User, Menu, X } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import { motion, AnimatePresence } from 'framer-motion';

interface HeaderProps {
  onShowLogin?: () => void;
  onShowUserDashboard?: () => void;
  onShowAdminDashboard?: () => void;
}

export default function Header({ onShowLogin, onShowUserDashboard, onShowAdminDashboard }: HeaderProps) {
  const { user, isAuthenticated } = useAuthStore();
  const { items, toggleCart } = useCartStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cartItemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="bg-orange-500 sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo and Brand */}
          <Link href="/" className="flex items-center gap-2 md:gap-3">
            <div className="relative">
              <ChefHat className="w-8 h-8 md:w-10 md:h-10 text-white" />
              <span className="absolute -top-1 -right-1 text-lg">🔥</span>
            </div>
            <div>
              <h1 className="text-white font-bold text-sm md:text-lg lg:text-xl">
                AYAM GEPREK SAMBAL IJO
              </h1>
              <p className="text-white/90 text-xs md:text-sm hidden sm:block">
                Pedas Segarnya Bikin Nagih!
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-white hover:text-white/80 transition-colors font-medium">
              Home
            </Link>
            <Link href="#menu" className="text-white hover:text-white/80 transition-colors font-medium">
              Menu
            </Link>
            <Link href="#promo" className="text-white hover:text-white/80 transition-colors font-medium">
              Promo
            </Link>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* Cart Button */}
            <button
              onClick={toggleCart}
              className="relative p-2 text-white hover:bg-white/10 rounded-full transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItemCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold"
                >
                  {cartItemCount}
                </motion.span>
              )}
            </button>

            {/* Auth Button */}
            <div className="hidden md:block">
              {isAuthenticated ? (
                <button
                  onClick={() => {
                    if (user?.role === 'admin') {
                      onShowAdminDashboard?.();
                    } else {
                      onShowUserDashboard?.();
                    }
                  }}
                  className="flex items-center gap-2 bg-white text-orange-500 px-4 py-2 rounded-full font-semibold hover:bg-white/90 transition-colors"
                >
                  <User className="w-4 h-4" />
                  {user?.username}
                </button>
              ) : (
                <button
                  onClick={onShowLogin}
                  className="bg-white text-orange-500 px-4 py-2 rounded-full font-semibold hover:bg-white/90 transition-colors"
                >
                  Login
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden pb-4"
            >
              <nav className="flex flex-col gap-3">
                <Link href="/" className="text-white hover:text-white/80 transition-colors font-medium">
                  Home
                </Link>
                <Link href="#menu" className="text-white hover:text-white/80 transition-colors font-medium">
                  Menu
                </Link>
                <Link href="#promo" className="text-white hover:text-white/80 transition-colors font-medium">
                  Promo
                </Link>
                {isAuthenticated ? (
                  <button
                    onClick={() => {
                      if (user?.role === 'admin') {
                        onShowAdminDashboard?.();
                      } else {
                        onShowUserDashboard?.();
                      }
                      setMobileMenuOpen(false);
                    }}
                    className="text-left text-white hover:text-white/80 transition-colors font-medium flex items-center gap-2"
                  >
                    <User className="w-4 h-4" />
                    {user?.username}
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      onShowLogin?.();
                      setMobileMenuOpen(false);
                    }}
                    className="text-left text-white hover:text-white/80 transition-colors font-medium"
                  >
                    Login
                  </button>
                )}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
