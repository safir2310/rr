'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Plus, Edit, Trash2, X, Save, LogOut, Package, Users, Settings, Receipt, ChefHat, Download } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  isPromotion: boolean;
  isNew: boolean;
  stock: number;
}

interface User {
  id: string;
  username: string;
  email: string;
  phone: string | null;
  role: string;
  points: number;
  photo: string | null;
}

interface Order {
  id: string;
  orderNumber: string;
  status: string;
  totalAmount: number;
  pointsEarned: number;
  createdAt: string;
  customerNotes: string | null;
  user: {
    id: string;
    username: string;
    email: string;
    phone: string | null;
  };
  orderItems: {
    product: {
      name: string;
      price: number;
    };
    quantity: number;
  }[];
}

interface AdminDashboardProps {
  onClose: () => void;
}

export default function AdminDashboard({ onClose }: AdminDashboardProps) {
  const { user, logout } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'products' | 'users' | 'store' | 'transactions'>('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [storeSettings, setStoreSettings] = useState({
    name: '',
    slogan: '',
    logo: '',
    phone: '',
    address: '',
    instagram: '',
    facebook: ''
  });

  // Product form state
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    image: '',
    category: 'food',
    isPromotion: false,
    isNew: false,
    stock: 0
  });
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);

  // User form state
  const [userForm, setUserForm] = useState({
    username: '',
    email: '',
    phone: '',
    password: ''
  });
  const [showUserForm, setShowUserForm] = useState(false);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    try {
      if (activeTab === 'products') {
        const res = await fetch('/api/products');
        const data = await res.json();
        setProducts(data.products || []);
      } else if (activeTab === 'users') {
        const res = await fetch('/api/users');
        const data = await res.json();
        setUsers(data.users || []);
      } else if (activeTab === 'store') {
        const res = await fetch('/api/store');
        const data = await res.json();
        if (data.settings) {
          setStoreSettings({
            name: data.settings.name || '',
            slogan: data.settings.slogan || '',
            logo: data.settings.logo || '',
            phone: data.settings.phone || '',
            address: data.settings.address || '',
            instagram: data.settings.instagram || '',
            facebook: data.settings.facebook || ''
          });
        }
      } else if (activeTab === 'transactions') {
        const res = await fetch('/api/orders');
        const data = await res.json();
        setOrders(data.orders || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Product functions
  const handleSaveProduct = async () => {
    setLoading(true);
    try {
      const payload = {
        ...productForm,
        price: Number(productForm.price),
        stock: Number(productForm.stock)
      };

      if (editingProduct) {
        await fetch(`/api/products/${editingProduct.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } else {
        await fetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      setShowProductForm(false);
      setEditingProduct(null);
      setProductForm({
        name: '',
        description: '',
        price: 0,
        image: '',
        category: 'food',
        isPromotion: false,
        isNew: false,
        stock: 0
      });
      fetchData();
    } catch (error) {
      alert('Gagal menyimpan produk');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Yakin ingin menghapus produk ini?')) return;

    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
      fetchData();
    } catch (error) {
      alert('Gagal menghapus produk');
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductForm(product);
    setShowProductForm(true);
  };

  // User functions
  const handleSaveUser = async () => {
    setLoading(true);
    try {
      await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userForm)
      });

      setShowUserForm(false);
      setUserForm({ username: '', email: '', phone: '', password: '' });
      fetchData();
    } catch (error) {
      alert('Gagal menambah user');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm('Yakin ingin menghapus user ini?')) return;

    try {
      await fetch(`/api/users/${id}`, { method: 'DELETE' });
      fetchData();
    } catch (error) {
      alert('Gagal menghapus user');
    }
  };

  const handleUpdateUserPoints = async (userId: string, points: number) => {
    try {
      await fetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ points })
      });
      fetchData();
    } catch (error) {
      alert('Gagal mengupdate point user');
    }
  };

  // Store settings functions
  const handleSaveStoreSettings = async () => {
    setLoading(true);
    try {
      await fetch('/api/store', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(storeSettings)
      });
      alert('Pengaturan toko berhasil disimpan!');
    } catch (error) {
      alert('Gagal menyimpan pengaturan toko');
    } finally {
      setLoading(false);
    }
  };

  // Order functions
  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      await fetch('/api/orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, status })
      });
      fetchData();
    } catch (error) {
      alert('Gagal mengupdate status pesanan');
    }
  };

  const handleViewReceipt = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/receipt`);
      const data = await res.json();

      if (res.ok && data.receipt) {
        // Create a new window with the receipt
        const receiptWindow = window.open('', '_blank');
        if (receiptWindow) {
          receiptWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
              <title>Struk Pesanan</title>
              <style>
                body {
                  font-family: 'Courier New', monospace;
                  padding: 20px;
                  background: #f5f5f5;
                  display: flex;
                  justify-content: center;
                }
                .receipt {
                  background: white;
                  padding: 30px;
                  max-width: 400px;
                  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .receipt h2 {
                  text-align: center;
                  margin-bottom: 20px;
                  color: #f97316;
                }
                .receipt pre {
                  white-space: pre-wrap;
                  line-height: 1.6;
                }
                @media print {
                  body { background: white; }
                  .receipt { box-shadow: none; }
                }
              </style>
            </head>
            <body>
              <div class="receipt">
                <h2>AYAM GEPREK SAMBAL IJO</h2>
                <pre>${data.receipt.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
                <button onclick="window.print()" style="margin-top: 20px; padding: 10px 20px; background: #f97316; color: white; border: none; border-radius: 5px; cursor: pointer; width: 100%;">
                  Cetak Struk
                </button>
              </div>
            </body>
            </html>
          `);
          receiptWindow.document.close();
        }
      } else {
        alert('Struk tidak ditemukan');
      }
    } catch (error) {
      console.error('Error viewing receipt:', error);
      alert('Gagal memuat struk');
    }
  };

  const handleLogout = () => {
    logout();
    localStorage.removeItem('user');
    onClose();
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-orange-400 flex items-center justify-center">
        <p className="text-white text-xl">Akses ditolak</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-orange-400">
      {/* Header */}
      <header className="bg-orange-500 sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="flex items-center gap-2 text-white hover:text-white/80 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-semibold">Kembali</span>
              </button>
              <div className="flex items-center gap-2">
                <ChefHat className="w-6 h-6 text-white" />
                <span className="text-white font-bold">Admin Dashboard</span>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-full text-white hover:bg-white/20 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline font-semibold text-sm">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="bg-white shadow-md sticky top-16 z-40">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto gap-1 py-2">
            {[
              { id: 'products' as const, label: 'Produk', icon: Package },
              { id: 'users' as const, label: 'User', icon: Users },
              { id: 'store' as const, label: 'Toko', icon: Settings },
              { id: 'transactions' as const, label: 'Transaksi', icon: Receipt }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-orange-500 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        {activeTab === 'products' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Add Product Button */}
            <button
              onClick={() => {
                setEditingProduct(null);
                setProductForm({
                  name: '',
                  description: '',
                  price: 0,
                  image: '',
                  category: 'food',
                  isPromotion: false,
                  isNew: false,
                  stock: 0
                });
                setShowProductForm(true);
              }}
              className="flex items-center gap-2 bg-white text-orange-500 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-xl transition-shadow"
            >
              <Plus className="w-5 h-5" />
              Tambah Produk
            </button>

            {/* Product Form Modal */}
            <AnimatePresence>
              {showProductForm && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
                >
                  <motion.div
                    initial={{ scale: 0.9, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.9, y: 20 }}
                    className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto"
                  >
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-800">
                          {editingProduct ? 'Edit Produk' : 'Tambah Produk'}
                        </h2>
                        <button
                          onClick={() => {
                            setShowProductForm(false);
                            setEditingProduct(null);
                          }}
                          className="p-1 hover:bg-gray-100 rounded-full"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Nama Produk</label>
                          <input
                            type="text"
                            value={productForm.name || ''}
                            onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                          <textarea
                            value={productForm.description || ''}
                            onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                            rows={3}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Harga</label>
                            <input
                              type="number"
                              value={productForm.price || 0}
                              onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Stok</label>
                            <input
                              type="number"
                              value={productForm.stock || 0}
                              onChange={(e) => setProductForm({ ...productForm, stock: Number(e.target.value) })}
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">URL Gambar</label>
                          <input
                            type="text"
                            value={productForm.image || ''}
                            onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                            placeholder="https://..."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                          <select
                            value={productForm.category || 'food'}
                            onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          >
                            <option value="food">Makanan</option>
                            <option value="drink">Minuman</option>
                          </select>
                        </div>
                        <div className="flex gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={productForm.isPromotion || false}
                              onChange={(e) => setProductForm({ ...productForm, isPromotion: e.target.checked })}
                              className="w-4 h-4 text-orange-500"
                            />
                            <span className="text-sm font-medium text-gray-700">Produk Promosi</span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={productForm.isNew || false}
                              onChange={(e) => setProductForm({ ...productForm, isNew: e.target.checked })}
                              className="w-4 h-4 text-orange-500"
                            />
                            <span className="text-sm font-medium text-gray-700">Produk Baru</span>
                          </label>
                        </div>
                        <button
                          onClick={handleSaveProduct}
                          disabled={loading}
                          className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors disabled:opacity-50"
                        >
                          {loading ? 'Menyimpan...' : 'Simpan'}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Products List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {products.map((product) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-xl shadow-lg p-4"
                >
                  <div className="flex gap-4">
                    <div className="w-20 h-20 bg-orange-100 rounded-lg overflow-hidden flex-shrink-0">
                      {product.image ? (
                        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-orange-300 text-2xl">🍗</div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-800 mb-1">{product.name}</h3>
                      <p className="text-orange-600 font-bold mb-2">{formatPrice(product.price)}</p>
                      <div className="flex gap-2 flex-wrap">
                        {product.isPromotion && (
                          <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">Promo</span>
                        )}
                        {product.isNew && (
                          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Baru</span>
                        )}
                        <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full">
                          {product.category === 'food' ? 'Makanan' : 'Minuman'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => handleEditProduct(product)}
                      className="flex-1 flex items-center justify-center gap-2 bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600 transition-colors"
                    >
                      <Edit className="w-4 h-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteProduct(product.id)}
                      className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            {products.length === 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <p className="text-gray-500">Belum ada produk</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'users' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <button
              onClick={() => {
                setUserForm({ username: '', email: '', phone: '', password: '' });
                setShowUserForm(true);
              }}
              className="flex items-center gap-2 bg-white text-orange-500 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-xl transition-shadow"
            >
              <Plus className="w-5 h-5" />
              Tambah User
            </button>

            {/* User Form Modal */}
            <AnimatePresence>
              {showUserForm && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
                >
                  <motion.div
                    initial={{ scale: 0.9, y: 20 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.9, y: 20 }}
                    className="bg-white rounded-2xl shadow-2xl max-w-md w-full"
                  >
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-800">Tambah User</h2>
                        <button
                          onClick={() => setShowUserForm(false)}
                          className="p-1 hover:bg-gray-100 rounded-full"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                          <input
                            type="text"
                            value={userForm.username}
                            onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                          <input
                            type="email"
                            value={userForm.email}
                            onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">No HP</label>
                          <input
                            type="tel"
                            value={userForm.phone}
                            onChange={(e) => setUserForm({ ...userForm, phone: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                          <input
                            type="password"
                            value={userForm.password}
                            onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                          />
                        </div>
                        <button
                          onClick={handleSaveUser}
                          disabled={loading}
                          className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors disabled:opacity-50"
                        >
                          {loading ? 'Menyimpan...' : 'Simpan'}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Users List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {users.map((userItem) => (
                <motion.div
                  key={userItem.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-xl shadow-lg p-4"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-gray-800">{userItem.username}</h3>
                      <p className="text-sm text-gray-500">{userItem.email}</p>
                      {userItem.phone && <p className="text-sm text-gray-500">{userItem.phone}</p>}
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      userItem.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {userItem.role}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Point</p>
                      <p className="font-bold text-orange-600">{userItem.points}</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleUpdateUserPoints(userItem.id, Math.max(0, userItem.points - 10))}
                        className="px-3 py-1 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
                      >
                        -10
                      </button>
                      <button
                        onClick={() => handleUpdateUserPoints(userItem.id, userItem.points + 10)}
                        className="px-3 py-1 bg-green-100 text-green-600 rounded-lg hover:bg-green-200"
                      >
                        +10
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteUser(userItem.id)}
                    className="w-full flex items-center justify-center gap-2 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    Hapus User
                  </button>
                </motion.div>
              ))}
            </div>

            {users.length === 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <p className="text-gray-500">Belum ada user</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'store' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-6">Pengaturan Toko</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nama Toko</label>
                  <input
                    type="text"
                    value={storeSettings.name}
                    onChange={(e) => setStoreSettings({ ...storeSettings, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Slogan</label>
                  <input
                    type="text"
                    value={storeSettings.slogan}
                    onChange={(e) => setStoreSettings({ ...storeSettings, slogan: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">URL Logo</label>
                  <input
                    type="text"
                    value={storeSettings.logo}
                    onChange={(e) => setStoreSettings({ ...storeSettings, logo: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">No HP</label>
                  <input
                    type="text"
                    value={storeSettings.phone}
                    onChange={(e) => setStoreSettings({ ...storeSettings, phone: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                  <textarea
                    value={storeSettings.address}
                    onChange={(e) => setStoreSettings({ ...storeSettings, address: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    rows={3}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Instagram URL</label>
                  <input
                    type="text"
                    value={storeSettings.instagram}
                    onChange={(e) => setStoreSettings({ ...storeSettings, instagram: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="https://instagram.com/..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Facebook URL</label>
                  <input
                    type="text"
                    value={storeSettings.facebook}
                    onChange={(e) => setStoreSettings({ ...storeSettings, facebook: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="https://facebook.com/..."
                  />
                </div>
                <button
                  onClick={handleSaveStoreSettings}
                  disabled={loading}
                  className="w-full bg-orange-500 text-white py-3 rounded-lg font-bold hover:bg-orange-600 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Menyimpan...' : 'Simpan Pengaturan'}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'transactions' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {orders.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <p className="text-gray-500">Belum ada transaksi</p>
              </div>
            ) : (
              orders.map((order) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-2xl shadow-lg p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Order #{order.orderNumber}</p>
                      <p className="font-bold text-gray-800">{formatDate(order.createdAt)}</p>
                      <p className="text-sm text-gray-600">{order.user.username} ({order.user.email})</p>
                      {order.user.phone && <p className="text-sm text-gray-600">{order.user.phone}</p>}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {order.status === 'pending' ? 'Menunggu' :
                       order.status === 'processing' ? 'Diproses' :
                       order.status === 'completed' ? 'Selesai' : order.status}
                    </span>
                  </div>

                  {order.customerNotes && (
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600"><strong>Catatan:</strong> {order.customerNotes}</p>
                    </div>
                  )}

                  <div className="space-y-2 mb-4">
                    {order.orderItems.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span className="text-gray-600">{item.quantity}x {item.product.name}</span>
                        <span className="font-semibold">{formatPrice(item.product.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Total</p>
                      <p className="font-bold text-xl text-orange-600">{formatPrice(order.totalAmount)}</p>
                    </div>
                    {order.status === 'completed' && order.pointsEarned > 0 && (
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Point User</p>
                        <p className="font-bold text-green-600">+{order.pointsEarned} poin</p>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => handleUpdateOrderStatus(order.id, 'processing')}
                        className="flex-1 bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition-colors"
                      >
                        Proses Pesanan
                      </button>
                    )}
                    {order.status === 'processing' && (
                      <button
                        onClick={() => handleUpdateOrderStatus(order.id, 'completed')}
                        className="flex-1 bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600 transition-colors"
                      >
                        Selesaikan Pesanan
                      </button>
                    )}
                    <button
                      onClick={() => handleViewReceipt(order.id)}
                      className="flex items-center justify-center gap-2 bg-orange-100 text-orange-600 py-2 rounded-lg font-semibold hover:bg-orange-200 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      <span>Struk</span>
                    </button>
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
