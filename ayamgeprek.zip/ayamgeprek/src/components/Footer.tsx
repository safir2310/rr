'use client';

import Link from 'next/link';
import { ChefHat, Facebook, Instagram } from 'lucide-react';

interface FooterProps {
  storeSettings?: {
    name: string;
    slogan: string;
    phone: string;
    address: string;
    instagram: string | null;
    facebook: string | null;
  };
}

export default function Footer({ storeSettings }: FooterProps) {
  const settings = storeSettings || {
    name: 'AYAM GEPREK SAMBAL IJO',
    slogan: 'Pedas Segarnya Bikin Nagih!',
    phone: '085260812758',
    address: 'Jl. Medan - Banda Aceh, Simpang Camat, Gampong Tijue, Kec. Pidie, Kab. Pidie, 24151',
    instagram: null,
    facebook: null
  };

  return (
    <footer className="bg-orange-500 text-white mt-auto">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Brand */}
          <div className="flex flex-col items-start gap-4">
            <div className="flex items-center gap-2">
              <div className="relative">
                <ChefHat className="w-10 h-10 text-white" />
                <span className="absolute -top-1 -right-1 text-lg">🔥</span>
              </div>
              <h3 className="font-bold text-lg">{settings.name}</h3>
            </div>
            <p className="text-white/90 text-sm">{settings.slogan}</p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-4">Kontak</h4>
            <div className="space-y-2">
              <p className="text-white/90 text-sm flex items-center gap-2">
                <span>📞</span>
                <a href={`tel:${settings.phone}`} className="hover:text-white">
                  {settings.phone}
                </a>
              </p>
            </div>
          </div>

          {/* Address */}
          <div>
            <h4 className="font-bold text-lg mb-4">Alamat</h4>
            <p className="text-white/90 text-sm leading-relaxed">
              {settings.address}
            </p>
          </div>

          {/* Social Media */}
          <div>
            <h4 className="font-bold text-lg mb-4">Ikuti Kami</h4>
            <div className="flex gap-4">
              {settings.instagram && (
                <Link
                  href={settings.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </Link>
              )}
              {settings.facebook && (
                <Link
                  href={settings.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </Link>
              )}
              {!settings.instagram && !settings.facebook && (
                <p className="text-white/70 text-sm">Belum ada link</p>
              )}
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/20 mt-8 pt-8 text-center">
          <p className="text-white/80 text-sm">
            © {new Date().getFullYear()} {settings.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
