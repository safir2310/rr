import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET cart items for user
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID diperlukan' }, { status: 400 });
    }

    const cartItems = await db.cartItem.findMany({
      where: { userId },
      include: {
        product: true
      }
    });

    return NextResponse.json({ cartItems }, { status: 200 });
  } catch (error) {
    console.error('Get cart error:', error);
    return NextResponse.json({ error: 'Gagal mengambil keranjang' }, { status: 500 });
  }
}

// POST add item to cart
export async function POST(req: NextRequest) {
  try {
    const { userId, productId, quantity } = await req.json();

    if (!userId || !productId || !quantity) {
      return NextResponse.json({ error: 'Semua field wajib diisi' }, { status: 400 });
    }

    // Check if item already in cart
    const existingCartItem = await db.cartItem.findUnique({
      where: {
        userId_productId: {
          userId,
          productId
        }
      }
    });

    let cartItem;

    if (existingCartItem) {
      // Update quantity
      cartItem = await db.cartItem.update({
        where: {
          userId_productId: {
            userId,
            productId
          }
        },
        data: {
          quantity: existingCartItem.quantity + quantity
        },
        include: {
          product: true
        }
      });
    } else {
      // Create new cart item
      cartItem = await db.cartItem.create({
        data: {
          userId,
          productId,
          quantity
        },
        include: {
          product: true
        }
      });
    }

    return NextResponse.json({ cartItem }, { status: 201 });
  } catch (error) {
    console.error('Add to cart error:', error);
    return NextResponse.json({ error: 'Gagal menambah ke keranjang' }, { status: 500 });
  }
}

// PUT update cart item
export async function PUT(req: NextRequest) {
  try {
    const { cartItemId, quantity } = await req.json();

    const cartItem = await db.cartItem.update({
      where: { id: cartItemId },
      data: { quantity },
      include: {
        product: true
      }
    });

    return NextResponse.json({ cartItem }, { status: 200 });
  } catch (error) {
    console.error('Update cart error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate keranjang' }, { status: 500 });
  }
}

// DELETE cart item
export async function DELETE(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const cartItemId = searchParams.get('id');

    if (!cartItemId) {
      return NextResponse.json({ error: 'Cart item ID diperlukan' }, { status: 400 });
    }

    await db.cartItem.delete({
      where: { id: cartItemId }
    });

    return NextResponse.json({ message: 'Item berhasil dihapus dari keranjang' }, { status: 200 });
  } catch (error) {
    console.error('Delete cart item error:', error);
    return NextResponse.json({ error: 'Gagal menghapus item' }, { status: 500 });
  }
}
