import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

// GET single user
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await db.user.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        username: true,
        email: true,
        phone: true,
        address: true,
        role: true,
        points: true,
        photo: true,
        createdAt: true
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({ user }, { status: 200 });
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json({ error: 'Gagal mengambil user' }, { status: 500 });
  }
}

// PUT update user
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { username, email, phone, address, photo, newPassword } = await req.json();

    const updateData: any = {};
    if (username) updateData.username = username;
    if (email) updateData.email = email;
    if (phone !== undefined) updateData.phone = phone;
    if (address !== undefined) updateData.address = address;
    if (photo !== undefined) updateData.photo = photo;

    if (newPassword) {
      updateData.password = await bcrypt.hash(newPassword, 10);
    }

    const user = await db.user.update({
      where: { id: params.id },
      data: updateData,
      select: {
        id: true,
        username: true,
        email: true,
        phone: true,
        address: true,
        role: true,
        points: true,
        photo: true,
        updatedAt: true
      }
    });

    return NextResponse.json({ user }, { status: 200 });
  } catch (error) {
    console.error('Update user error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate user' }, { status: 500 });
  }
}

// PUT update user points (admin only)
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { points } = await req.json();

    if (points === undefined) {
      return NextResponse.json({ error: 'Nilai point diperlukan' }, { status: 400 });
    }

    const user = await db.user.update({
      where: { id: params.id },
      data: { points },
      select: {
        id: true,
        username: true,
        email: true,
        points: true
      }
    });

    return NextResponse.json({ user }, { status: 200 });
  } catch (error) {
    console.error('Update points error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate point' }, { status: 500 });
  }
}

// DELETE user (admin only)
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await db.user.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ message: 'User berhasil dihapus' }, { status: 200 });
  } catch (error) {
    console.error('Delete user error:', error);
    return NextResponse.json({ error: 'Gagal menghapus user' }, { status: 500 });
  }
}
