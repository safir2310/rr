import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET store settings
export async function GET() {
  try {
    let settings = await db.storeSettings.findFirst();

    // Create default settings if not exists
    if (!settings) {
      settings = await db.storeSettings.create({
        data: {
          name: 'AYAM GEPREK SAMBAL IJO',
          slogan: 'Pedas Segarnya Bikin Nagih!',
          phone: '085260812758',
          address: 'Jl. Medan - Banda Aceh, Simpang Camat, Gampong Tijue, Kec. Pidie, Kab. Pidie, 24151'
        }
      });
    }

    return NextResponse.json({ settings }, { status: 200 });
  } catch (error) {
    console.error('Get store settings error:', error);
    return NextResponse.json({ error: 'Gagal mengambil pengaturan toko' }, { status: 500 });
  }
}

// PUT update store settings (admin only)
export async function PUT(req: NextRequest) {
  try {
    const { name, slogan, logo, phone, address, instagram, facebook } = await req.json();

    let settings = await db.storeSettings.findFirst();

    if (!settings) {
      // Create settings if not exists
      settings = await db.storeSettings.create({
        data: {
          name,
          slogan,
          logo,
          phone,
          address,
          instagram,
          facebook
        }
      });
    } else {
      // Update existing settings
      settings = await db.storeSettings.update({
        where: { id: settings.id },
        data: {
          name,
          slogan,
          logo,
          phone,
          address,
          instagram,
          facebook
        }
      });
    }

    return NextResponse.json({ settings }, { status: 200 });
  } catch (error) {
    console.error('Update store settings error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate pengaturan toko' }, { status: 500 });
  }
}
