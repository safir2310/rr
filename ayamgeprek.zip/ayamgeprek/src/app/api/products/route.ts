import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all products
export async function GET() {
  try {
    const products = await db.product.findMany({
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ products }, { status: 200 });
  } catch (error) {
    console.error('Get products error:', error);
    return NextResponse.json({ error: 'Gagal mengambil produk' }, { status: 500 });
  }
}

// POST create new product (admin only)
export async function POST(req: NextRequest) {
  try {
    const { name, description, price, image, category, isPromotion, isNew, stock } = await req.json();

    const product = await db.product.create({
      data: {
        name,
        description,
        price,
        image,
        category,
        isPromotion: isPromotion || false,
        isNew: isNew || false,
        stock: stock || 0
      }
    });

    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    console.error('Create product error:', error);
    return NextResponse.json({ error: 'Gagal menambah produk' }, { status: 500 });
  }
}
