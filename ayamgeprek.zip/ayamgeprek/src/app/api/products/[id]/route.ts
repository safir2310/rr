import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET single product
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const product = await db.product.findUnique({
      where: { id: params.id }
    });

    if (!product) {
      return NextResponse.json({ error: 'Produk tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({ product }, { status: 200 });
  } catch (error) {
    console.error('Get product error:', error);
    return NextResponse.json({ error: 'Gagal mengambil produk' }, { status: 500 });
  }
}

// PUT update product
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { name, description, price, image, category, isPromotion, isNew, stock } = await req.json();

    const product = await db.product.update({
      where: { id: params.id },
      data: {
        name,
        description,
        price,
        image,
        category,
        isPromotion,
        isNew,
        stock
      }
    });

    return NextResponse.json({ product }, { status: 200 });
  } catch (error) {
    console.error('Update product error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate produk' }, { status: 500 });
  }
}

// DELETE product
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await db.product.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ message: 'Produk berhasil dihapus' }, { status: 200 });
  } catch (error) {
    console.error('Delete product error:', error);
    return NextResponse.json({ error: 'Gagal menghapus produk' }, { status: 500 });
  }
}
