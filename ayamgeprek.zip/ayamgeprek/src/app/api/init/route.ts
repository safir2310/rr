import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    console.log('Initializing sample data...');

    // Create default store settings
    const existingStore = await db.storeSettings.findFirst();
    if (!existingStore) {
      await db.storeSettings.create({
        data: {
          name: 'AYAM GEPREK SAMBAL IJO',
          slogan: 'Pedas Segarnya Bikin Nagih!',
          phone: '085260812758',
          address: 'Jl. Medan - Banda Aceh, Simpang Camat, Gampong Tijue, Kec. Pidie, Kab. Pidie, 24151',
          instagram: 'https://instagram.com/ayamgepreksambalijo',
          facebook: 'https://facebook.com/ayamgepreksambalijo'
        }
      });
      console.log('Store settings created');
    }

    // Create sample products
    const existingProducts = await db.product.count();
    if (existingProducts === 0) {
      const products = [
        {
          name: 'Ayam Geprek Sambal Ijo',
          description: 'Ayam geprek dengan sambal ijo pedas, disajikan dengan nasi dan lalapan segar',
          price: 15000,
          category: 'food',
          isPromotion: true,
          isNew: true,
          stock: 50
        },
        {
          name: 'Ayam Geprek Original',
          description: 'Ayam geprek dengan sambal merah, disajikan dengan nasi dan lalapan',
          price: 12000,
          category: 'food',
          isPromotion: false,
          isNew: false,
          stock: 50
        },
        {
          name: 'Ayam Geprek Keju',
          description: 'Ayam geprek dengan topping keju meleleh dan sambal ijo',
          price: 18000,
          category: 'food',
          isPromotion: true,
          isNew: false,
          stock: 30
        },
        {
          name: 'Ayam Geprek Telur Dadar',
          description: 'Ayam geprek dengan telur dadar, sambal ijo, dan nasi',
          price: 17000,
          category: 'food',
          isPromotion: false,
          isNew: true,
          stock: 30
        },
        {
          name: 'Es Teh Manis',
          description: 'Es teh manis segar',
          price: 5000,
          category: 'drink',
          isPromotion: false,
          isNew: false,
          stock: 100
        },
        {
          name: 'Es Jeruk',
          description: 'Es jeruk segar',
          price: 6000,
          category: 'drink',
          isPromotion: false,
          isNew: false,
          stock: 100
        },
        {
          name: 'Jus Alpukat',
          description: 'Jus alpukat creamy dengan susu coklat',
          price: 12000,
          category: 'drink',
          isPromotion: false,
          isNew: true,
          stock: 50
        },
        {
          name: 'Paket Hemat 1',
          description: 'Ayam Geprek Sambal Ijo + Nasi + Es Teh Manis',
          price: 18000,
          category: 'food',
          isPromotion: true,
          isNew: true,
          stock: 25
        }
      ];

      for (const product of products) {
        await db.product.create({ data: product });
      }
      console.log('Sample products created');
    }

    return NextResponse.json({ message: 'Data initialized successfully' }, { status: 200 });
  } catch (error) {
    console.error('Initialization error:', error);
    return NextResponse.json({ error: 'Failed to initialize data' }, { status: 500 });
  }
}
