import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET order receipt
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const order = await db.order.findUnique({
      where: { id: params.id },
      include: {
        user: true,
        orderItems: {
          include: {
            product: true
          }
        },
        receipts: true
      }
    });

    if (!order) {
      return NextResponse.json({ error: 'Pesanan tidak ditemukan' }, { status: 404 });
    }

    const receipt = order.receipts?.[0];

    if (!receipt) {
      return NextResponse.json({ error: 'Struk tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({ receipt }, { status: 200 });
  } catch (error) {
    console.error('Get receipt error:', error);
    return NextResponse.json({ error: 'Gagal mengambil struk' }, { status: 500 });
  }
}
