import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all orders for user or admin
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const userId = searchParams.get('userId');

    const orders = await db.order.findMany({
      where: userId ? { userId } : undefined,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            email: true,
            phone: true
          }
        },
        orderItems: {
          include: {
            product: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ orders }, { status: 200 });
  } catch (error) {
    console.error('Get orders error:', error);
    return NextResponse.json({ error: 'Gagal mengambil pesanan' }, { status: 500 });
  }
}

// POST create new order
export async function POST(req: NextRequest) {
  try {
    const { userId, cartItems, customerNotes } = await req.json();

    if (!userId || !cartItems || cartItems.length === 0) {
      return NextResponse.json({ error: 'Data pesanan tidak lengkap' }, { status: 400 });
    }

    // Calculate total amount
    let totalAmount = 0;
    const orderItemsData = [];

    for (const cartItem of cartItems) {
      totalAmount += cartItem.product.price * cartItem.quantity;
      orderItemsData.push({
        productId: cartItem.product.id,
        quantity: cartItem.quantity,
        price: cartItem.product.price
      });
    }

    // Generate order number
    const orderNumber = `ORD${Date.now()}`;

    // Create order with order items
    const order = await db.order.create({
      data: {
        orderNumber,
        userId,
        totalAmount,
        customerNotes,
        status: 'pending',
        orderItems: {
          create: orderItemsData
        }
      },
      include: {
        user: true,
        orderItems: {
          include: {
            product: true
          }
        }
      }
    });

    // Create digital receipt
    const receiptContent = `
AYAM GEPREK SAMBAL IJO
=====================

Order #${orderNumber}
Tanggal: ${new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })}

Customer: ${order.user.username}
Email: ${order.user.email}
${order.user.phone ? `No HP: ${order.user.phone}` : ''}

---------------------
ITEM PESANAN:
---------------------
${order.orderItems.map(item => 
  `${item.quantity}x ${item.product.name} - ${new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(item.price * item.quantity)}`
).join('\n')}

---------------------
TOTAL: ${new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(totalAmount)}
=====================

${customerNotes ? `Catatan: ${customerNotes}` : ''}

Status: Menunggu Persetujuan

Terima kasih telah berbelanja!
`.trim();

    await db.receipt.create({
      data: {
        orderId: order.id,
        content: receiptContent
      }
    });

    // Clear cart
    await db.cartItem.deleteMany({
      where: { userId }
    });

    return NextResponse.json({ order }, { status: 201 });
  } catch (error) {
    console.error('Create order error:', error);
    return NextResponse.json({ error: 'Gagal membuat pesanan' }, { status: 500 });
  }
}

// PUT update order status
export async function PUT(req: NextRequest) {
  try {
    const { orderId, status } = await req.json();

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: {
        user: true
      }
    });

    if (!order) {
      return NextResponse.json({ error: 'Pesanan tidak ditemukan' }, { status: 404 });
    }

    // Calculate points if order is completed
    let pointsEarned = order.pointsEarned;
    if (status === 'completed' && order.status !== 'completed') {
      // Award points: 1 point per 1000 rupiah
      pointsEarned = Math.floor(order.totalAmount / 1000);

      // Update user points
      await db.user.update({
        where: { id: order.userId },
        data: {
          points: {
            increment: pointsEarned
          }
        }
      });
    }

    // Update order status
    const updatedOrder = await db.order.update({
      where: { id: orderId },
      data: {
        status,
        pointsEarned
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            email: true,
            phone: true,
            points: true
          }
        },
        orderItems: {
          include: {
            product: true
          }
        }
      }
    });

    return NextResponse.json({ order: updatedOrder }, { status: 200 });
  } catch (error) {
    console.error('Update order error:', error);
    return NextResponse.json({ error: 'Gagal mengupdate pesanan' }, { status: 500 });
  }
}
