import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  try {
    const { username, email, phone, password, role, birthDate, verificationCode } = await req.json();

    // Validate input
    if (!username || !email || !password) {
      return NextResponse.json({ error: 'Semua field wajib diisi' }, { status: 400 });
    }

    // Check if user already exists
    const existingUser = await db.user.findFirst({
      where: {
        OR: [
          { username },
          { email }
        ]
      }
    });

    if (existingUser) {
      return NextResponse.json({ error: 'Username atau email sudah terdaftar' }, { status: 400 });
    }

    // For admin registration, verify verification code
    if (role === 'admin') {
      if (!birthDate || !verificationCode) {
        return NextResponse.json({ error: 'Tanggal lahir dan kode verifikasi wajib diisi' }, { status: 400 });
      }

      // Generate 6-digit code from birth date (DDMMYY)
      const birthDateObj = new Date(birthDate);
      const day = String(birthDateObj.getDate()).padStart(2, '0');
      const month = String(birthDateObj.getMonth() + 1).padStart(2, '0');
      const year = String(birthDateObj.getFullYear()).slice(-2);
      const expectedCode = `${day}${month}${year}`;

      if (verificationCode !== expectedCode) {
        return NextResponse.json({ error: 'Kode verifikasi salah' }, { status: 400 });
      }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = await db.user.create({
      data: {
        username,
        email,
        phone: phone || null,
        password: hashedPassword,
        role: role || 'user',
        points: 0
      },
      select: {
        id: true,
        username: true,
        email: true,
        phone: true,
        role: true,
        points: true,
        createdAt: true
      }
    });

    return NextResponse.json({ user }, { status: 201 });
  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json({ error: 'Gagal mendaftar' }, { status: 500 });
  }
}
