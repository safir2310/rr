'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import PromotionPopup from '@/components/PromotionPopup';
import CartModal from '@/components/CartModal';
import AuthModal from '@/components/AuthModal';
import UserDashboard from '@/components/UserDashboard';
import AdminDashboard from '@/components/AdminDashboard';
import { useCartStore } from '@/store/cartStore';
import { useAuthStore } from '@/store/authStore';
import { motion } from 'framer-motion';
import { ChefHat, Sparkles, Star } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  isPromotion: boolean;
  isNew: boolean;
}

interface StoreSettings {
  name: string;
  slogan: string;
  phone: string;
  address: string;
  instagram: string | null;
  facebook: string | null;
}

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [storeSettings, setStoreSettings] = useState<StoreSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [showUserDashboard, setShowUserDashboard] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);

  const { items: cartItems, isOpen: isCartOpen, toggleCart } = useCartStore();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Initialize data if needed
      await fetch('/api/init', { method: 'POST' });

      const [productsRes, storeRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/store')
      ]);

      const productsData = await productsRes.json();
      const storeData = await storeRes.json();

      setProducts(productsData.products || []);
      setStoreSettings(storeData.settings);

      // Initialize cart from localStorage if available
      const savedCart = localStorage.getItem('cart');
      if (savedCart) {
        useCartStore.getState().setItems(JSON.parse(savedCart));
      }

      // Initialize auth from localStorage if available
      const savedUser = localStorage.getItem('user');
      if (savedUser) {
        useAuthStore.getState().setUser(JSON.parse(savedUser));
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product: Product) => {
    const cartItem = {
      id: `${Date.now()}`,
      productId: product.id,
      quantity: 1,
      product
    };
    useCartStore.getState().addItem(cartItem);
  };

  const handleCheckout = (cartItems: any[]) => {
    // Show success notification
    alert('Pesanan berhasil dibuat! Check WhatsApp untuk konfirmasi.');
  };

  const filteredProducts = {
    all: products,
    food: products.filter(p => p.category === 'food'),
    drinks: products.filter(p => p.category === 'drink'),
    promotion: products.filter(p => p.isPromotion),
    new: products.filter(p => p.isNew)
  };

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-orange-400">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="inline-block"
          >
            <ChefHat className="w-16 h-16 text-white" />
          </motion.div>
          <p className="text-white font-bold mt-4">Memuat...</p>
        </div>
      </div>
    );
  }

  // Show Dashboard components
  if (showUserDashboard) {
    return <UserDashboard onClose={() => setShowUserDashboard(false)} />;
  }

  if (showAdminDashboard) {
    return <AdminDashboard onClose={() => setShowAdminDashboard(false)} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-orange-400">
      <Header
        onShowLogin={() => setShowLogin(true)}
        onShowUserDashboard={() => setShowUserDashboard(true)}
        onShowAdminDashboard={() => setShowAdminDashboard(true)}
      />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-orange-400 via-orange-500 to-red-500 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center text-white"
          >
            <div className="flex justify-center mb-6">
              <div className="relative">
                <ChefHat className="w-20 h-20 md:w-28 md:h-28" />
                <motion.span
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute -top-2 -right-2 text-4xl"
                >
                  🔥
                </motion.span>
              </div>
            </div>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4">
              AYAM GEPREK SAMBAL IJO
            </h1>
            <p className="text-xl md:text-2xl mb-6 text-white/90">
              Pedas Segarnya Bikin Nagih!
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-orange-500 px-8 py-3 rounded-full font-bold text-lg hover:bg-white/90 transition-colors shadow-lg"
            >
              Pesan Sekarang
            </motion.button>
          </motion.div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-10 left-10 opacity-20 text-6xl animate-pulse">🍗</div>
        <div className="absolute bottom-10 right-10 opacity-20 text-6xl animate-pulse">🌶️</div>
        <div className="absolute top-1/2 left-20 opacity-10 text-8xl">🔥</div>
      </section>

      {/* Promo Section */}
      {filteredProducts.promotion.length > 0 && (
        <section id="promo" className="py-12 bg-orange-400">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-8"
            >
              <div className="flex items-center justify-center gap-3 mb-2">
                <Sparkles className="w-8 h-8 text-yellow-300" />
                <h2 className="text-3xl md:text-4xl font-bold text-white text-center">
                  Promo Spesial
                </h2>
                <Sparkles className="w-8 h-8 text-yellow-300" />
              </div>
              <p className="text-white/90 text-center">Penawaran terbatas untuk Anda</p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.promotion.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Products Section */}
      <section id="menu" className="py-12 bg-orange-400">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-2">
              Menu Kami
            </h2>
            <p className="text-white/90 text-center">Pilihan terbaik untuk Anda</p>
          </motion.div>

          {/* New Products */}
          {filteredProducts.new.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center gap-2 mb-6">
                <Star className="w-6 h-6 text-yellow-300" />
                <h3 className="text-2xl font-bold text-white">Produk Terbaru</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.new.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Food Items */}
          {filteredProducts.food.length > 0 && (
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-white mb-6">🍗 Menu Makanan</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.food.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Drink Items */}
          {filteredProducts.drinks.length > 0 && (
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">🥤 Menu Minuman</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.drinks.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </div>
            </div>
          )}

          {/* No Products Message */}
          {products.length === 0 && (
            <div className="text-center py-12">
              <p className="text-white/90 text-lg">
                Belum ada produk. Silakan login sebagai admin untuk menambahkan produk.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <Footer storeSettings={storeSettings} />

      {/* Modals */}
      <PromotionPopup onClose={() => {}} />
      <CartModal
        isOpen={isCartOpen}
        onClose={toggleCart}
        onCheckout={handleCheckout}
        onShowLogin={() => {
          setShowLogin(true);
          toggleCart();
        }}
      />
      <AuthModal
        isOpen={showLogin}
        onClose={() => setShowLogin(false)}
        onUserDashboard={() => {
          setShowLogin(false);
          setShowUserDashboard(true);
        }}
        onAdminDashboard={() => {
          setShowLogin(false);
          setShowAdminDashboard(true);
        }}
      />
    </div>
  );
}
